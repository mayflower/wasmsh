"""Tiny test fixture for wasmsh micropip install tests."""
__version__ = "0.1.0"
GREETING = "hello from wasmsh_test_fixture"
